#!/bin/bash

shower serve  --port=9090 --ui=true
